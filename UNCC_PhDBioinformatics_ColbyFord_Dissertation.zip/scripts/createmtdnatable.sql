CREATE TABLE [dbo].[mtDNA](
	[Taxa] [nvarchar](255) NULL,
	[GuthrieZone] [nvarchar](10) NULL,
	[BCMID] [nvarchar](255) NULL,
	[TaxaID] [nvarchar](255) NULL,
	[SampleID] [nvarchar](255) NULL,
	[mtDNA] [nvarchar](max) NULL
)