CREATE TABLE [dbo].[GeographicInformation](
	[GuthrieZone] [nvarchar](255) NULL,
	[BCM ID_FULL] [nvarchar](255) NULL,
	[BCM ID_SIMPLE] [nvarchar](255) NULL,
	[BCM ID_SUFFIX] [nvarchar](255) NULL,
	[BCM ID_INDEX] [int] NULL,
	[BCM Name] [nvarchar](255) NULL,
	[BCM FULL NAME] [nvarchar](255) NULL,
	[Long_Orig] [nvarchar](255) NULL,
	[Lat_Orig] [nvarchar](255) NULL,
	[Latitude] [float] NULL,
	[Longitude] [float] NULL
)