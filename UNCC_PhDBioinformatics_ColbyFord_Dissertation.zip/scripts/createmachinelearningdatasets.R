library(tidyr)
library(readr)
library(dplyr)

############
## Load Full Data
CombinedData <- read_csv("DimensionalityReduction_CombinedData_OuterJoin.csv") #Outer Join Data
colnames(CombinedData)[1] <- "TaxaID" #Fix <U+FEFF> Issues
CombinedData[ CombinedData == "NULL" ] <- NA


## Create mtDNA Dataset
mtDNA_cols <- paste0("mtDNA.pos", seq(1:16590))

mtDNAData <- CombinedData %>% 
  select(-TaxaID,
         -CulturalTaxa,
         -mtDNATaxa,
         -YchrTaxa,
         -Cultural_EthnogAtlas,
         -Ychr_STR) %>% 
  filter(complete.cases(.)) %>% 
  separate(.,
           mtDNA,
           mtDNA_cols,
           sep = seq(1:16590),
           remove = TRUE)
# Remove NA Columns
mtDNAData <- mtDNAData[!is.na(names(mtDNAData))]
mtDNAData$GuthrieZone <- as.factor(mtDNAData$GuthrieZone)

## Create Ychr Dataset
Ychr_cols <- paste0("Ychr.pos", seq(1:12))

YchrData <- CombinedData %>% 
  select(-TaxaID,
         -CulturalTaxa,
         -mtDNATaxa,
         -YchrTaxa,
         -Cultural_EthnogAtlas,
         -mtDNA) %>% 
  filter(complete.cases(.)) %>% 
  separate(.,
           Ychr_STR,
           Ychr_cols,
           sep = seq(1:12),
           remove = TRUE)
# Remove NA Columns
YchrData <- YchrData[!is.na(names(YchrData))]
YchrData$GuthrieZone <- as.factor(YchrData$GuthrieZone)

## Create Genetic Only Dataset
GeneticData <- CombinedData %>% 
  select(-TaxaID,
         -CulturalTaxa,
         -mtDNATaxa,
         -YchrTaxa,
         -Cultural_EthnogAtlas) %>% 
  filter(complete.cases(.)) %>%
  separate(.,
           mtDNA,
           mtDNA_cols,
           sep = seq(1:16590),
           remove = TRUE) %>% 
  separate(.,
           Ychr_STR,
           Ychr_cols,
           sep = seq(1:12),
           remove = TRUE)
# Remove NA Columns
GeneticData <- GeneticData[!is.na(names(GeneticData))]
GeneticData$GuthrieZone <- as.factor(GeneticData$GuthrieZone)

## Create Cultural Datasets
Cultural_cols <- paste0("Cultural.pos", seq(1:92))

CulturalData <- CombinedData %>% 
  select(-TaxaID,
         -CulturalTaxa,
         -mtDNATaxa,
         -YchrTaxa,
         -mtDNA,
         -Ychr_STR) %>% 
  filter(complete.cases(.)) %>% 
  separate(.,
           Cultural_EthnogAtlas,
           Cultural_cols,
           sep = seq(1:92),
           remove = TRUE)
# Remove NA Columns
CulturalData <- CulturalData[!is.na(names(CulturalData))]
CulturalData$GuthrieZone <- as.factor(CulturalData$GuthrieZone)

## Create Combined Datasets
CombinedData <- CombinedData %>% 
  select(-TaxaID,
         -CulturalTaxa,
         -mtDNATaxa,
         -YchrTaxa) %>% 
  #filter(complete.cases(.)) %>% 
  separate(.,
           mtDNA,
           mtDNA_cols,
           sep = seq(1:16590),
           remove = TRUE) %>% 
  separate(.,
           Ychr_STR,
           Ychr_cols,
           sep = seq(1:12),
           remove = TRUE) %>% 
  separate(.,
           Cultural_EthnogAtlas,
           Cultural_cols,
           sep = seq(1:92),
           remove = TRUE)
# Remove NA Columns
CombinedData <- CombinedData[!is.na(names(CombinedData))]
CombinedData$GuthrieZone <- as.factor(CombinedData$GuthrieZone)
