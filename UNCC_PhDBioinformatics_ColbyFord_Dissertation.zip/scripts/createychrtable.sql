CREATE TABLE [dbo].[Ychr](
	[Taxa] [nvarchar](255) NULL,
	[GuthrieZone] [nvarchar](10) NULL,
	[BCMID] [nvarchar](255) NULL,
	[TaxaID] [nvarchar](255) NULL,
	[SampleID] [nvarchar](255) NULL,
	[Ychr_STR] [nvarchar](255) NULL
)