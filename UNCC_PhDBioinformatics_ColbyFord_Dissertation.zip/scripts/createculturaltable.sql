CREATE TABLE [dbo].[Cultural](
	[Taxa] [nvarchar](255) NULL,
	[TaxaID] [nvarchar](255) NULL,
	[BCMID] [nvarchar](255) NULL,
	[GuthrieZone] [nvarchar](10) NULL,
	[Cultural_EthnogAtlas] [nvarchar](255) NULL
)